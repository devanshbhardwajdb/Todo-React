import React from 'react'

const About = () => {
  return (
    <div>
      this is an about component
      <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Saepe atque unde sequi neque eligendi vitae magni corrupti? Quae doloremque debitis molestias optio beatae dolores sit tenetur similique explicabo vero dignissimos esse est, voluptatem ea!</p>
    </div>
  )
}

export default About
